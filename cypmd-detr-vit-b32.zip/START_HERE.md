# DETR with selectable ResNet-50 or pretrained ViT-B/32

This bundle contains:

- `cypmd-detr/`: the complete updated repository reconstructed from your attachment.
- `changes.patch`: all additional files and modifications for your existing checkout.

Open `cypmd-detr/VIT_GUIDE.md` for the full instructions, `CHANGES.md` for the
per-file change list, and `VALIDATION.md` for test coverage and limitations.

## Use the complete repository

From `cypmd-detr/`, with a matching PyTorch/TorchVision installation:

```bash
python -m pip install -r requirements.txt

# Original ResNet-50 DETR
python train.py --model resnet50 --root ./voc --output_dir runs/resnet50

# Pretrained ViT-B/32, direct RGB patches, shared DETR decoder
python train.py --model vit_b_32 --root ./voc --img_size 640 640 \
  --batch_size 1 --learning_rate_encoder 1e-5 --output_dir runs/vit_b32
```

Use the appropriate path to your existing VOC dataset. The first pretrained
run downloads official encoder weights if needed. Dataset files and trained
weights are not included. Original README image assets were absent from the
attached repository text.

## Update an existing checkout

From its root:

```bash
git apply --check /path/to/changes.patch
git apply /path/to/changes.patch
```

Do not reapply the patch to the already updated `cypmd-detr/` directory. If
your checkout differs from the attachment, merge the changes using `CHANGES.md`.

The default model remains ResNet-50. To initialize the ViT model's compatible
queries/decoder/heads from your trained detector, add
`--init_decoder_from /path/to/old_weights.pt` and match its decoder settings,
class count and query count. See the guide for the exact compatibility rules.
